Sonic Icon Pack version 2
=========================

Requires Windows 95, MS Plus and a high colour graphics card!


For loads more Sonic addons such as wallpaper and a theme pack, surf to

http://dspace.dial.pipex.com/watts/andy/

email:  Andy Watts (sonic@dial.pipex.com)